// Exercise the actual shipped ES5 engine with Max API and clock stubs.
const vm=require('vm'), fs=require('fs'), path=require('path'), assert=require('assert');
const root=path.resolve(__dirname,'..');
let now=10000, outputs=[];
const context={Date:{now:()=>now},isFinite,Math,
    arrayfromargs:a=>Array.prototype.slice.call(a),
    outlet:(i,...args)=>outputs.push([i,...args]),
    Task:function(){this.cancel=()=>{};this.repeat=()=>{};}};
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(root,'glove_dual_engine.js'),'utf8'),context);
const c=context;
function latest(h){return outputs.filter(a=>a[0]===h).slice(-1)[0]?.[1];}
function close(a,b,tol=1e-8){assert(Math.abs(a-b)<tol,`${a} != ${b}`);}
let count=0;
function test(name,fn){fn();count++;console.log('PASS '+name);}
function reset(){outputs=[];c.reset();c.start();c.enabled(1);c.smooth(30);c.deadband(.003);}
test('legacy raw calibration, first frame immediate and five values',()=>{
 reset();c.rawleft(90,99,99,99,125);assert.equal(latest(0).length,5);latest(0).forEach(x=>close(x,.5));
});
test('right hand independent; clipping and normalized input',()=>{
 c.normright(-1,.2,.4,.6,2);assert.deepEqual(Array.from(latest(1)),[0,.2,.4,.6,1]);
 latest(0).forEach(x=>close(x,.5));
});
test('malformed packets do not change targets or refresh connection status',()=>{
 const before=c.hands[0].received;now+=12;
 c.rawleft(100,100);c.normleft(0,0,NaN,0,0);c.normleft(0,0,'0.2',0,0);c.normleft(0,0,Infinity,0,0);
 assert.equal(c.hands[0].received,before);c.hands[0].target.forEach(x=>close(x,.5));
 assert.equal(outputs.filter(a=>a[1]==='invalid').length,4);
});
test('deadband rejects tiny alternating jitter around accepted target',()=>{
 reset();c.normleft(.5,.5,.5,.5,.5);const emitted=outputs.filter(x=>x[0]===0).length;
 for(let i=0;i<100;i++){now+=10;c.normleft(.5+(i%2?.002:-.002),.5,.5,.5,.5);c.tick();}
 assert.equal(outputs.filter(x=>x[0]===0).length,emitted);
});
test('smooth step is monotone; time constant independent of scheduler interval',()=>{
 reset();c.normleft(0,0,0,0,0);c.normleft(1,1,1,1,1);now+=30;c.tick();
 close(latest(0)[0],1-Math.exp(-1));
 let previous=latest(0)[0];for(let i=0;i<30;i++){now+=10;c.tick();assert(latest(0)[0]>=previous);previous=latest(0)[0];}
 assert(previous>.9999);
 reset();c.normleft(0,0,0,0,0);c.normleft(1,1,1,1,1);for(let i=0;i<3;i++){now+=10;c.tick();}
 close(latest(0)[0],1-Math.exp(-1));
});
test('held target still converges; exact endpoint and no constant packet chatter',()=>{
 now+=500;c.tick();assert.equal(latest(0)[0],1);const emitted=outputs.length;
 for(let i=0;i<40;i++){now+=10;c.tick();}assert.equal(outputs.length,emitted);
});
test('stale hand holds last value, live packet restores status',()=>{
 const before=latest(0);now+=1200;c.tick();assert.equal(c.hands[0].status,'HOLD');assert.strictEqual(latest(0),before);
 c.normleft(1,1,1,1,1);assert.equal(c.hands[0].status,'LIVE');
});
test('bypass disables both filters and zero time bypasses only smoothing',()=>{
 reset();c.normleft(.5,.5,.5,.5,.5);c.enabled(0);c.normleft(.501,.501,.501,.501,.501);close(latest(0)[0],.501);
 c.enabled(1);c.smooth(0);c.normleft(.7,.7,.7,.7,.7);close(latest(0)[0],.7);
 c.normleft(.701,.701,.701,.701,.701);close(latest(0)[0],.7);
});
test('manual tests clamp values and update only selected channel',()=>{
 reset();c.smooth(0);c.manualright(4,2);assert.deepEqual(Array.from(latest(1)),[0,0,0,0,1]);assert.equal(c.hands[1].status,'TEST');
 c.manualright(9,.5);assert.deepEqual(Array.from(latest(1)),[0,0,0,0,1]);
});
test('flush repeats current frame without modifying it',()=>{
 const before=Array.from(latest(1));c.flush();assert.deepEqual(Array.from(latest(1)),before);
});
test('stationary real frames keep learning buses fresh without UI/OSC chatter',()=>{
 reset();c.normleft(.5,.5,.5,.5,.5);c.normright(.5,.5,.5,.5,.5);now+=10;c.tick();
 const monitors=outputs.filter(x=>x[0]<2).length;outputs=[];
 for(let i=0;i<100;i++){now+=20;c.normleft(.5,.5,.5,.5,.5);c.normright(.5,.5,.5,.5,.5);c.tick();}
 assert.equal(monitors,2);assert.equal(outputs.filter(x=>x[0]<2).length,0);
 assert.equal(outputs.filter(x=>x[0]===3).length,100);assert.equal(outputs.filter(x=>x[0]===4).length,100);
 outputs.filter(x=>x[0]>=3&&x[0]<5).forEach(x=>assert.deepEqual(Array.from(x[1]),[.5,.5,.5,.5,.5]));
 outputs=[];now+=20;c.tick();c.flush();assert.equal(outputs.filter(x=>x[0]>=3&&x[0]<5).length,0);
});
test('malformed, cancelled and overdue frames never refresh the learning buses',()=>{
 reset();c.normleft(.5,.5,.5,.5,.5);now+=101;c.tick();assert.equal(outputs.filter(x=>x[0]===3).length,0);
 outputs=[];c.normright(.5,.5,.5,.5,.5);c.lostright();now+=10;c.tick();assert.equal(outputs.filter(x=>x[0]===4).length,0);assert.equal(c.hands[1].status,'HOLD');
 c.normleft(.5,.5,NaN,.5,.5);now+=10;c.tick();assert.equal(outputs.filter(x=>x[0]===3).length,0);
});
test('optimized default reaches 95 percent within 25ms of a step',()=>{
 const oldNow=now;now=30000;outputs=[];
 const fast={...context,Task:function(){this.cancel=()=>{};this.repeat=()=>{};}};
 vm.createContext(fast);vm.runInContext(fs.readFileSync(path.join(root,'glove_dual_engine.js'),'utf8'),fast);
 assert.equal(fast.runner.interval,5);assert.equal(fast.tau,8);fast.start();
 fast.normleft(0,0,0,0,0);fast.normleft(1,1,1,1,1);
 let reached=0;for(let t=5;t<=30;t+=5){now=30000+t;fast.tick();if(!reached&&fast.hands[0].value[0]>=.95)reached=t;}
 assert.equal(reached,25);assert(fast.hands[0].value[0]>.97);now=oldNow;
});
test('drawing throttle never delays live mapping or the fresh learning bus',()=>{
 reset();c.smooth(0);c.normleft(0,0,0,0,0);outputs=[];
 now+=1;c.normleft(1,1,1,1,1);assert.equal(latest(0)[0],1);assert(!outputs.some(x=>x[0]===5));
 now+=5;c.tick();assert(outputs.some(x=>x[0]===3&&x[1][0]===1));assert(!outputs.some(x=>x[0]===5));
 now+=33;c.tick();assert(outputs.some(x=>x[0]===5&&x[1][0]===1));
});
test('200Hz control input paints only the latest value at about 30Hz',()=>{
 reset();c.smooth(0);c.deadband(0);c.normleft(0,0,0,0,0);outputs=[];
 for(let i=1;i<=500;i++){now+=5;c.normleft(i/500,i/500,i/500,i/500,i/500);c.tick();}
 assert.equal(outputs.filter(x=>x[0]===0).length,500);
 assert(outputs.filter(x=>x[0]===5).length<=Math.ceil(2500/33));
 now+=33;c.tick();assert.equal(outputs.filter(x=>x[0]===5).slice(-1)[0][1][0],1);
});
function calibrationReset(){c.swaphands(0);c.setvalueof('none');reset();c.enabled(0);}
function pose(h,values,normalized=false){for(let i=0;i<18;i++){now+=20;c[normalized?(h?'normright':'normleft'):(h?'rawright':'rawleft')](...values);c.tick();}}
test('independent per-finger calibration supports either sensor direction and 0.1 headroom',()=>{
 calibrationReset();const open=[20,30,40,150,160],fist=[120,130,140,50,60];
 pose(0,open);c.capture(0,'open');assert.equal(c.calibrated[0],null);
 pose(0,fist);c.capture(0,'fist');c.rawleft(...open);latest(0).forEach(v=>close(v,0));
 c.rawleft(...fist);latest(0).forEach(v=>close(v,.9));
 c.rawleft(...open.map((v,i)=>v+(fist[i]-v)/.9));latest(0).forEach(v=>close(v,1));
 c.rawleft(0,0,0,180,180);latest(0).forEach(v=>close(v,0));
 c.rawright(90,99,99,99,125);latest(1).forEach(v=>close(v,.5));
 pose(1,[10,20,30,40,50]);c.capture(1,'open');pose(1,[60,70,80,90,100]);c.capture(1,'fist');
 c.rawright(35,45,55,65,75);latest(1).forEach(v=>close(v,.45));c.rawleft(...fist);latest(0).forEach(v=>close(v,.9));
});
test('capture requires fresh stationary physical input, rejecting stale, moving and tiny spans',()=>{
 calibrationReset();c.manualleft(0,.5);c.capture(0,'open');assert.equal(c.poses[0].open,null);
 pose(0,[20,20,20,20,20]);now+=151;c.capture(0,'open');assert.equal(c.poses[0].open,null);
 for(let i=0;i<14;i++){now+=20;c.rawleft(i%2?20:30,20,20,20,20);}
 c.capture(0,'open');assert.equal(c.poses[0].open,null);
 pose(0,[20,20,20,20,20]);c.capture(0,'open');pose(0,[23,120,120,120,120]);c.capture(0,'fist');
 assert.equal(c.calibrated[0],null);assert.equal(c.poses[0].fist,null);assert(c.poses[0].open);
 c.reset();c.capture(0,'fist');assert.equal(c.calibrated[0],null);
});
test('recalibration keeps the last valid pair until a new pair passes validation',()=>{
 calibrationReset();pose(0,[20,20,20,20,20]);c.capture(0,'open');pose(0,[120,120,120,120,120]);c.capture(0,'fist');
 const saved=c.getvalueof();pose(0,[30,30,30,30,30]);c.capture(0,'open');assert.equal(c.getvalueof(),saved);
 pose(0,[31,31,31,31,31]);c.capture(0,'fist');assert.equal(c.getvalueof(),saved);
 pose(0,[130,130,130,130,130]);c.capture(0,'fist');assert.notEqual(c.getvalueof(),saved);
});
test('calibration capture and restore do not replay old frames into learning buses',()=>{
 calibrationReset();pose(0,[20,20,20,20,20]);c.capture(0,'open');pose(0,[120,120,120,120,120]);outputs=[];c.capture(0,'fist');c.tick();c.flush();
 assert(!outputs.some(v=>v[0]===3));assert(!c.hands[0].ready);
 now+=5;c.rawleft(120,120,120,120,120);c.tick();assert(outputs.some(v=>v[0]===3&&Math.abs(v[1][0]-.9)<1e-8));
 const saved=c.getvalueof();outputs=[];c.setvalueof(saved);c.tick();c.flush();assert(!outputs.some(v=>v[0]===3));
 assert.equal(c.hands[0].received,0);assert.equal(c.poses[0].recent.length,0);
});
test('JSON endpoints round-trip, corrupt recall is atomic, reset and stream changes preserve calibration',()=>{
 calibrationReset();pose(0,[20,20,20,20,20]);c.capture(0,'open');pose(0,[120,120,120,120,120]);c.capture(0,'fist');
 const saved=c.getvalueof();c.setvalueof('none');assert.equal(c.calibrated[0],null);c.setvalueof(saved);assert.equal(c.getvalueof(),saved);
 for(const bad of ['garbage','{}',JSON.stringify({version:1,hands:[{kind:'raw',open:{length:5},fist:[1,2,3,4,5]},null]}),saved.replace('120','20')]){c.setvalueof(bad);assert.equal(c.getvalueof(),saved);}
 c.reset();assert.equal(c.getvalueof(),saved);c.lostleft();assert.equal(c.getvalueof(),saved);
 c.normleft(.5,.5,.5,.5,.5);latest(0).forEach(v=>close(v,.5));c.rawleft(120,120,120,120,120);latest(0).forEach(v=>close(v,.9));
 c.clearcal(1);assert.equal(c.getvalueof(),saved);c.clearcal(0);assert.equal(c.calibrated[0],null);
 c.rawleft(90,99,99,99,125);latest(0).forEach(v=>close(v,.5));
});
test('normalized calibration is explicitly captured and never applied to raw-degree input',()=>{
 calibrationReset();pose(1,[.1,.1,.1,.1,.1],true);c.capture(1,'fist');pose(1,[.9,.9,.9,.9,.9],true);c.capture(1,'open');
 c.normright(.1,.1,.1,.1,.1);latest(1).forEach(v=>close(v,.9));c.normright(.9,.9,.9,.9,.9);latest(1).forEach(v=>close(v,0));
 c.normright(0,0,0,0,0);latest(1).forEach(v=>close(v,1));
 c.rawright(90,99,99,99,125);latest(1).forEach(v=>close(v,.5));
 pose(0,[20,20,20,20,20]);c.capture(0,'open');pose(0,[.9,.9,.9,.9,.9],true);c.capture(0,'fist');assert.equal(c.calibrated[0],null);
});
test('calibration averages captures only; next live frame and low-latency filtering remain immediate',()=>{
 calibrationReset();pose(0,[20,20,20,20,20]);now+=10;c.rawleft(21,21,21,21,21);c.capture(0,'open');
 close(c.poses[0].open[0],20+1/14);pose(0,[120,120,120,120,120]);c.capture(0,'fist');
 c.enabled(1);c.smooth(8);c.deadband(.003);now+=5;c.rawleft(...Array(5).fill(c.calibrated[0].open[0]));c.tick();
 now+=1;c.rawleft(120,120,120,120,120);for(let i=0;i<5;i++){now+=5;c.tick();}
 assert(c.hands[0].value[0]>.85);assert(c.hands[0].value[0]<.9);
});
test('raw diagnostics expose the original thumb angle behind a 0.3 default display',()=>{
 calibrationReset();c.rawright(90,99,99,99,103);c.calreport();
 close(latest(1)[4],.3);
 assert(outputs.some(v=>v[0]===2&&v[1]==='caldata'&&v[2]===1&&v[3]==='input4'&&v[4]==='103.0'));
 assert(outputs.some(v=>v[1]==='caldata'&&v[3]==='input_label'&&v[4].includes('raw degrees')));
 pose(1,[20,20,20,20,80]);c.capture(1,'open');pose(1,[120,120,120,120,110]);c.capture(1,'fist');
 assert(outputs.some(v=>v[1]==='caldata'&&v[2]===1&&v[3]==='open4'&&v[4]==='80.0'));
 assert(outputs.some(v=>v[1]==='caldata'&&v[2]===1&&v[3]==='fist4'&&v[4]==='110.0'));
});
test('inspection is read-only, flags stale data, retains endpoints on reconnect and caps output at 5Hz',()=>{
 const pending=c.hands[1].pendingBus,received=c.hands[1].received;c.calreport();
 assert.equal(c.hands[1].pendingBus,pending);assert.equal(c.hands[1].received,received);
 outputs=[];for(let i=0;i<39;i++){now+=5;c.calinspect(1,false,now);}
 assert.equal(outputs.length,0);now+=5;c.calinspect(1,false,now);
 assert(outputs.some(v=>v[3]==='input_label'&&v[4].includes('stale')));
 c.reset();assert(outputs.some(v=>v[3]==='input_label'&&v[4]==='Input: no data'));
 outputs=[];c.calreport();assert(outputs.some(v=>v[3]==='fist4'&&v[4]==='110.0'));
 assert(!outputs.some(v=>v[0]===3||v[0]===4));
});
test('Swap L/R exchanges complete raw/normalized routes and faults, without synthetic learning frames',()=>{
 calibrationReset();c.rawleft(90,99,99,99,125);c.rawright(180,180,180,180,180);c.tick();outputs=[];c.swaphands(1);c.tick();
 assert(!outputs.some(v=>v[0]===3||v[0]===4));assert(!c.hands[0].ready&&!c.hands[1].ready);
 c.rawleft(90,99,99,99,125);c.rawright(180,180,180,180,180);c.tick();
 c.hands[0].value.forEach(v=>close(v,1));c.hands[1].value.forEach(v=>close(v,.5));
 assert(outputs.some(v=>v[0]===3&&v[1][4]===1));assert(outputs.some(v=>v[0]===4&&v[1][4]===.5));
 c.lostright();assert.equal(c.hands[0].status,'HOLD');assert.equal(c.hands[1].status,'LIVE');
 c.normleft(.2,.2,.2,.2,.2);c.hands[1].value.forEach(v=>close(v,.2));c.swaphands(0);
});
test('calibration stays with physical input across swapping and Set recall order',()=>{
 calibrationReset();pose(0,[20,20,20,20,20]);c.capture(0,'open');pose(0,[120,120,120,120,120]);c.capture(0,'fist');
 const saved=c.getvalueof();c.swaphands(1);assert.equal(c.getvalueof(),saved);c.setvalueof(saved);
 c.rawleft(120,120,120,120,120);c.hands[1].value.forEach(v=>close(v,.9));
 pose(1,[30,30,30,30,30]);c.capture(0,'open');pose(1,[130,130,130,130,130]);c.capture(0,'fist');
 assert.equal(c.calibrated[1].open[0],30);assert.equal(c.calibrated[0].open[0],20);
 c.clearcal(0);assert.equal(c.calibrated[1],null);assert(c.calibrated[0]);c.swaphands(0);c.setvalueof(saved);
 c.rawleft(120,120,120,120,120);c.hands[0].value.forEach(v=>close(v,.9));
});
console.log(`${count} engine checks passed including routing, calibration, raw diagnostics and low-latency control/UI regressions.`);
