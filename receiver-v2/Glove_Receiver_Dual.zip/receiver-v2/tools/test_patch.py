#!/usr/bin/env python3
import json, struct
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=json.loads((root/'Glove_Receiver_Dual.maxpat').read_text())['patcher']
native_maps=[];params=[]
def walk(p):
    ids={o['box']['id']:o['box'] for o in p['boxes']}
    assert len(ids)==len(p['boxes'])
    for o in p['lines']:
        l=o['patchline']
        for end,count in [('source','numoutlets'),('destination','numinlets')]:
            id,i=l[end];assert id in ids
            if count in ids[id]: assert 0<=i<ids[id][count],str(l)
    for b in ids.values():
        if b.get('text','').startswith('live.map'):native_maps.append(b)
        v=b.get('saved_attribute_attributes',{}).get('valueof')
        if b.get('parameter_enable') and v:params.append(v['parameter_longname'])
        if 'patcher' in b:walk(b['patcher'])
walk(p);assert len(native_maps)==0
assert all(b['saved_object_attributes']['_persistence']==1 for b in native_maps)
assert len(params)==len(set(params)), 'Live parameter names must be globally unique'
ids={o['box']['id']:o['box'] for o in p['boxes']}
lines={(tuple(l['patchline']['source']),tuple(l['patchline']['destination'])) for l in p['lines']}
for h,name in enumerate(['left','right']):
    assert ids[name+'_udp']['text']=='udpreceive '+str([7000,6000][h])
    assert (('engine',3+h),(name+'_send',0)) in lines
    assert (('engine',h),(name+'_osc_gate',1)) in lines
    assert ids[name+'_send']['text']=='s G'+name.capitalize()
    assert ids[name+'_osc_prefix']['text']=='prepend /G'+name.capitalize()
    assert ((name+'_udp',0),(name+'_input_gate',1)) in lines
    assert ((name+'_input_gate',0),(name+'_route',0)) in lines
    assert (('usb_controller',2),(name+'_input_gate',0)) in lines
    for ch,finger in enumerate(['pinky','ring','middle','index','thumb']):
        n=name+'_'+finger
        assert ids[n]['ignoreclick']==1
        assert n+'_map' not in ids and n+'_remote' not in ids and n+'_signal' not in ids
assert (('audioin',0),('audioout',0)) in lines
assert (('audioin',1),('audioout',1)) in lines
assert ids['osc_port']['saved_attribute_attributes']['valueof']['parameter_type']==0
assert ids['host_state']['saved_attribute_attributes']['valueof']['parameter_type']==3
assert ids['osc_enable']['saved_attribute_attributes']['valueof']['parameter_initial']==[0]
assert ids['engine']['numoutlets']==7
assert ids['input_mode']['saved_attribute_attributes']['valueof']['parameter_enum']==['OSC','USB']
assert '@autoopen 0' in ids['serial']['text'] and '@baud 115200' in ids['serial']['text']
assert (('usb_controller',0),('serial',0)) in lines
assert '@asyncread 1' in ids['serial']['text'] and '@defer 0' in ids['serial']['text']
for a,o,b,i in [('serial',0,'serial_group',0),('serial',1,'serial_route',0),
 ('serial_route',0,'serial_read_setup',0),('serial_read_setup',1,'serial_group_clear',0),
 ('serial_group_clear',0,'serial_group',0),('serial_read_setup',0,'serial_group_size',0),
 ('serial_group_size',0,'serial_group',1),('serial_group',0,'serial_batch_defer',0),
 ('serial_batch_defer',0,'usb_controller',0),('serial_route',1,'serial_info',0),
 ('serial_info',0,'serial_info_defer',0),('serial_info_defer',0,'usb_controller',0)]:
    assert ((a,o),(b,i)) in lines
assert ids['serial_group']['text']=='zl group 1 @zlmaxsize 2048'
assert ids['smooth_ms']['saved_attribute_attributes']['valueof']['parameter_initial']==[8]
for h,name in enumerate(['left','right']):
    assert (('engine',5+h),(name+'_monitor_unpack',0)) in lines
    assert (('engine',5+h),(name+'_art',0)) in lines
    for ch,finger in enumerate(['pinky','ring','middle','index','thumb']):
        assert ((name+'_monitor_unpack',ch),(name+'_'+finger+'_set',0)) in lines
        assert name+'_unpack' not in ids
assert (('usb_controller',1),('engine',0)) in lines
assert (('usb_controller',3),('usb_settings',0)) in lines
assert (('usb_controller',4),('usb_settings',1)) in lines
assert '@bindto usb_controller' in ids['usb_saved_port']['text']
assert '@bindto engine' in ids['calibration_state']['text']
assert ids['calibration_state']['saved_attribute_attributes']['valueof']['parameter_type']==3
assert ids['statusroute']['text']=='route status calstatus caldata routing'
assert (('statusroute',1),('calroute',0)) in lines
for n in ['glove_dual_engine.js','glove_hands.js','glove_usb_serial.js']:
    assert any(d['name']==n for d in p['dependency_cache'])
    assert (root/n).is_file()
visible=[b for b in ids.values() if b.get('presentation') and b['maxclass']!='jsui']
for b in visible:
    x,y,w,h=b['presentation_rect'];assert x>=0 and y>=0 and x+w<=648 and y+h<=169,b['id']
for i,b in enumerate(visible):
    x,y,w,h=b['presentation_rect']
    for a in visible[i+1:]:
        xx,yy,ww,hh=a['presentation_rect']
        assert min(x+w,xx+ww)-max(x,xx)<=0 or min(y+h,yy+hh)-max(y,yy)<=0,(b['id'],a['id'])
usb=ids['usb_settings']['patcher']
uids={o['box']['id']:o['box'] for o in usb['boxes']}
ulines={(tuple(l['patchline']['source']),tuple(l['patchline']['destination'])) for l in usb['lines']}
assert (('usb_setup_control',0),('usb_settings',0)) in lines
assert ids['usb_setup_press']['text']=='t b'
for i,target in enumerate(['usb_ports','usb_status']):
    assert (('usb_in_'+str(i),0),(target,0)) in ulines
for i,source in enumerate(['usb_ports','usb_refresh','usb_connect','usb_close']):
    assert ((source,0),('usb_out_'+str(i),0)) in ulines
    assert (('usb_settings',i),('usb_'+['chooseport','refresh','connect','disconnect'][i]+'_command',0)) in lines
assert (('swap_hands',0),('usb_out_4',0)) in ulines
assert (('usb_settings',4),('swap_command',0)) in lines
assert (('swap_command',0),('engine',0)) in lines and ids['swap_command']['text']=='prepend swaphands'
assert (('statusroute',3),('swap_title',0)) in lines
assert (('swap_title',0),('usb_controller',0)) in lines
assert uids['swap_hands']['saved_attribute_attributes']['valueof']['parameter_initial']==[0]
uv=[b for b in uids.values() if b.get('presentation')]
for i,b in enumerate(uv):
    x,y,w,h=b['presentation_rect'];assert x>=0 and y>=0 and x+w<=580 and y+h<=80
    for a in uv[i+1:]:
        xx,yy,ww,hh=a['presentation_rect']
        assert min(x+w,xx+ww)-max(x,xx)<=0 or min(y+h,yy+hh)-max(y,yy)<=0,(b['id'],a['id'])
b=(root/'Glove_Receiver_Dual.amxd').read_bytes()
assert b[:12]==b'ampf\x04\x00\x00\x00aaaa'
assert struct.unpack('<I',b[28:32])[0]==len(b)-32
assert json.loads(b[32:].rstrip(b'\0'))=={'patcher':p}
for h,name in enumerate(['left','right']):
    popup=ids[name+'_calibration']['patcher']
    pi={o['box']['id']:o['box'] for o in popup['boxes']}
    pl={(tuple(l['patchline']['source']),tuple(l['patchline']['destination'])) for l in popup['lines']}
    assert ((name+'_calibration',0),('engine',0)) in lines
    assert ((name+'_cal_control',0),(name+'_calibration',0)) in lines
    assert (('calroute',h),(name+'_cal_statusset',0)) in lines
    assert (('caldataroute',h),(name+'_calibration',0)) in lines
    assert (('statusroute',2),('caldataroute',0)) in lines
    assert ids[name+'_cal_press']['text']=='t b b'
    for pose in ['open','fist','clear']:
        assert pi['cal_'+pose+'_bang']['text']=='t b'
        assert pi['cal_'+pose+'_command']['text']==(f'clearcal {h}' if pose=='clear' else f'capture {h} {pose}')
        assert (('cal_'+pose,0),('cal_'+pose+'_bang',0)) in pl
        assert (('cal_'+pose+'_command',0),('cal_output',0)) in pl
    pv=[b for b in pi.values() if b.get('presentation')]
    for i,b in enumerate(pv):
        x,y,w,height=b['presentation_rect'];assert 0<=x and 0<=y and x+w<=440 and y+height<=222
        for a in pv[i+1:]:
            xx,yy,ww,hh=a['presentation_rect']
            assert min(x+w,xx+ww)-max(x,xx)<=0 or min(y+height,yy+hh)-max(y,yy)<=0,(b['id'],a['id'])
print('PASS: AMXD payload, recursive patch links, unique parameters, no mapping or remote objects,')
print('      independent mapping bus outputs, calibration capture/recall wiring, popup bounds, gated OSC + USB,')
print('      fresh-frame buses, stereo passthrough and 648 × 169 layout bounds/overlap.')
